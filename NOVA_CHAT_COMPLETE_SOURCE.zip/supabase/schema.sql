-- NOVA CHAT database schema. Run once in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  phone text unique,
  username text unique,
  display_name text not null default 'مستخدم NOVA',
  avatar_url text,
  bio text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  type text not null default 'direct' check (type in ('direct','group')),
  title text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('member','admin','owner')),
  joined_at timestamptz not null default now(),
  primary key (conversation_id,user_id)
);
create table if not exists public.messages (
  id uuid primary key,
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  message_type text not null default 'text',
  content text not null default '',
  created_at timestamptz not null default now(),
  edited_at timestamptz,
  deleted_at timestamptz
);
create table if not exists public.message_receipts (
  message_id uuid not null references public.messages(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'delivered' check (status in ('delivered','read')),
  updated_at timestamptz not null default now(), primary key(message_id,user_id)
);
create table if not exists public.attachments (
  id uuid primary key default gen_random_uuid(), message_id uuid not null references public.messages(id) on delete cascade,
  file_path text not null, file_type text, file_size bigint, created_at timestamptz not null default now()
);
create table if not exists public.reactions (
  message_id uuid not null references public.messages(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  emoji text not null, created_at timestamptz not null default now(), primary key(message_id,user_id,emoji)
);
create table if not exists public.groups (
  id uuid primary key references public.conversations(id) on delete cascade,
  name text not null, avatar_url text, owner_id uuid references public.profiles(id) on delete set null
);
create table if not exists public.channels (
  id uuid primary key default gen_random_uuid(), owner_id uuid not null references public.profiles(id) on delete cascade,
  name text not null, description text, avatar_url text, invite_code text unique default encode(gen_random_bytes(8),'hex'), created_at timestamptz not null default now()
);
create table if not exists public.channel_members (
  channel_id uuid not null references public.channels(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null default 'subscriber', joined_at timestamptz not null default now(), primary key(channel_id,user_id)
);
create table if not exists public.stories (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
  media_path text, text_content text, created_at timestamptz not null default now(), expires_at timestamptz not null default now() + interval '24 hours'
);
create table if not exists public.calls (
  id uuid primary key default gen_random_uuid(), caller_id uuid not null references public.profiles(id), receiver_id uuid references public.profiles(id),
  conversation_id uuid references public.conversations(id), call_type text not null check(call_type in ('audio','video')),
  status text not null default 'initiated', started_at timestamptz, ended_at timestamptz, created_at timestamptz not null default now()
);
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null, payload jsonb not null default '{}'::jsonb, read_at timestamptz, created_at timestamptz not null default now()
);

create index if not exists messages_conversation_created_idx on public.messages(conversation_id,created_at desc);
create index if not exists conversation_members_user_idx on public.conversation_members(user_id);
create index if not exists profiles_phone_idx on public.profiles(phone);
create index if not exists stories_expiry_idx on public.stories(expires_at);

-- Create a profile automatically after phone OTP creates an auth user.
create or replace function public.handle_new_nova_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, phone, display_name)
  values (new.id, new.phone, 'مستخدم NOVA')
  on conflict (id) do update set phone = excluded.phone;
  return new;
end; $$;
drop trigger if exists on_nova_auth_user_created on auth.users;
create trigger on_nova_auth_user_created after insert or update on auth.users
for each row execute procedure public.handle_new_nova_user();

-- Safely create/find a direct conversation between the signed-in user and another user.
create or replace function public.create_direct_conversation(other_user_id uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare current_user_id uuid := auth.uid(); found_id uuid;
begin
  if current_user_id is null then raise exception 'Authentication required'; end if;
  if other_user_id is null or other_user_id = current_user_id then raise exception 'Invalid recipient'; end if;
  if not exists(select 1 from public.profiles where id = other_user_id) then raise exception 'User not found'; end if;
  select c.id into found_id from public.conversations c
  where c.type='direct'
    and exists(select 1 from public.conversation_members a where a.conversation_id=c.id and a.user_id=current_user_id)
    and exists(select 1 from public.conversation_members b where b.conversation_id=c.id and b.user_id=other_user_id)
    and (select count(*) from public.conversation_members x where x.conversation_id=c.id)=2
  limit 1;
  if found_id is not null then return found_id; end if;
  insert into public.conversations(type,created_by) values('direct',current_user_id) returning id into found_id;
  insert into public.conversation_members(conversation_id,user_id,role) values
    (found_id,current_user_id,'owner'),(found_id,other_user_id,'member');
  return found_id;
end; $$;
grant execute on function public.create_direct_conversation(uuid) to authenticated;

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.message_receipts enable row level security;
alter table public.attachments enable row level security;
alter table public.reactions enable row level security;
alter table public.groups enable row level security;
alter table public.channels enable row level security;
alter table public.channel_members enable row level security;
alter table public.stories enable row level security;
alter table public.calls enable row level security;
alter table public.notifications enable row level security;

-- Policies are dropped first so this script can be safely re-run.
drop policy if exists "profiles visible to authenticated users" on public.profiles;
drop policy if exists "users insert own profile" on public.profiles;
drop policy if exists "users update own profile" on public.profiles;
create policy "profiles visible to authenticated users" on public.profiles for select to authenticated using (true);
create policy "users insert own profile" on public.profiles for insert to authenticated with check (auth.uid()=id);
create policy "users update own profile" on public.profiles for update to authenticated using (auth.uid()=id) with check (auth.uid()=id);

drop policy if exists "members read conversations" on public.conversations;
create policy "members read conversations" on public.conversations for select to authenticated using (exists(select 1 from public.conversation_members m where m.conversation_id=id and m.user_id=auth.uid()));
drop policy if exists "members read memberships" on public.conversation_members;
create policy "members read memberships" on public.conversation_members for select to authenticated using (user_id=auth.uid() or exists(select 1 from public.conversation_members m where m.conversation_id=conversation_id and m.user_id=auth.uid()));
drop policy if exists "members read messages" on public.messages;
drop policy if exists "members send messages" on public.messages;
drop policy if exists "senders edit messages" on public.messages;
create policy "members read messages" on public.messages for select to authenticated using (exists(select 1 from public.conversation_members m where m.conversation_id=messages.conversation_id and m.user_id=auth.uid()));
create policy "members send messages" on public.messages for insert to authenticated with check (sender_id=auth.uid() and exists(select 1 from public.conversation_members m where m.conversation_id=messages.conversation_id and m.user_id=auth.uid()));
create policy "senders edit messages" on public.messages for update to authenticated using(sender_id=auth.uid()) with check(sender_id=auth.uid());

create policy "users manage own receipts" on public.message_receipts for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "members read attachments" on public.attachments for select to authenticated using(exists(select 1 from public.messages msg join public.conversation_members cm on cm.conversation_id=msg.conversation_id where msg.id=message_id and cm.user_id=auth.uid()));
create policy "members add reactions" on public.reactions for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "channel members view channels" on public.channels for select to authenticated using(owner_id=auth.uid() or exists(select 1 from public.channel_members cm where cm.channel_id=id and cm.user_id=auth.uid()));
create policy "channel owners manage channels" on public.channels for all to authenticated using(owner_id=auth.uid()) with check(owner_id=auth.uid());
create policy "channel members view membership" on public.channel_members for select to authenticated using(user_id=auth.uid() or exists(select 1 from public.channels c where c.id=channel_id and c.owner_id=auth.uid()));
create policy "users read active stories" on public.stories for select to authenticated using(expires_at>now());
create policy "users manage own stories" on public.stories for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "call participants read calls" on public.calls for select to authenticated using(caller_id=auth.uid() or receiver_id=auth.uid() or exists(select 1 from public.conversation_members cm where cm.conversation_id=conversation_id and cm.user_id=auth.uid()));
create policy "users read own notifications" on public.notifications for select to authenticated using(user_id=auth.uid());
create policy "users update own notifications" on public.notifications for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());

-- Enable Realtime for messages in Supabase Dashboard: Database > Publications > supabase_realtime.
-- Create a private Storage bucket named "nova-media" and add member-aware storage policies before file uploads.

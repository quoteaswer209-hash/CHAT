# NOVA CHAT feature scope

The product brief is retained as the target specification, with AI removed and phone OTP as the only authentication method.

| Area | Included in this starter | Additional work required |
|---|---|---|
| Visual identity, Arabic RTL, dark/light | Yes | Final device-by-device UX polish |
| Splash/loading and phone OTP gate | Yes | Configure Supabase SMS provider |
| Profile bootstrap | Basic | Full profile editor, avatar upload, username rules, QR |
| Home/chat list | Real account data, empty state | Favorites, archive, mute, pin, unread filters |
| Direct text messaging | Supabase insert/read + Realtime subscription | Receipts, typing, edit/delete, reactions, search |
| Offline text queue | IndexedDB cache + pending queue | Robust retry/backoff, conflict handling, complete cache policy |
| Media/files/voice notes | Schema foundation | Storage policies, upload UI, playback, file validation |
| Groups | Schema foundation | Create/manage UI and role enforcement |
| Channels | Schema foundation | Publishing/subscription UI and moderation |
| Stories | Schema foundation | Media, viewers, privacy and expiry UI |
| Audio/video calls | Call table foundation | WebRTC signaling, STUN/TURN, native call UX |
| Push notifications | Notifications table foundation | FCM, server function and native permissions |
| End-to-end encryption | Not implemented | Integrate audited protocol and key management |
| Nearby Bluetooth/Wi-Fi Direct | Not implemented | Native Android plugin, permissions and peer discovery |
| NOVA AI | Removed | Not in product scope |

Do not mark an item complete based only on its database table or visual button.

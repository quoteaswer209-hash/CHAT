import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Plus, Settings, MessageCircle, Users, Radio, Phone, Send, Paperclip, Moon, Sun, Wifi, WifiOff, LogOut, CheckCheck, UserRound, MoreVertical, Bell, Shield, Archive, ArrowLeft, RefreshCw } from 'lucide-react';
import { supabase, isSupabaseConfigured } from './lib/supabase';
import { localDb, type LocalMessage } from './lib/db';
import { syncPendingMessages, savePendingMessage } from './lib/messages';

type Profile = { id: string; username: string | null; display_name: string; avatar_url: string | null; phone?: string };
type Chat = { id: string; title: string; type: 'direct' | 'group'; lastMessage?: string; updated_at?: string; unread?: number };

const fmt = (value?: string) => value ? new Date(value).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }) : '';

export default function App() {
  const [dark, setDark] = useState(true);
  const [online, setOnline] = useState(navigator.onLine);
  const [sessionUser, setSessionUser] = useState<string | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [phone, setPhone] = useState('+20');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [chats, setChats] = useState<Chat[]>([]);
  const [active, setActive] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<LocalMessage[]>([]);
  const [draft, setDraft] = useState('');
  const [search, setSearch] = useState('');
  const [section, setSection] = useState('الدردشات');
  const [showSettings, setShowSettings] = useState(false);
  const [newPhone, setNewPhone] = useState('');

  useEffect(() => {
    const on = () => setOnline(true); const off = () => setOnline(false);
    window.addEventListener('online', on); window.addEventListener('offline', off);
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off); };
  }, []);

  useEffect(() => {
    if (!supabase) { setAuthLoading(false); return; }
    let alive = true;
    supabase.auth.getSession().then(({ data }) => { if (alive) { setSessionUser(data.session?.user.id ?? null); setAuthLoading(false); } });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => { setSessionUser(session?.user.id ?? null); setAuthLoading(false); });
    return () => { alive = false; listener.subscription.unsubscribe(); };
  }, []);

  useEffect(() => {
    if (!sessionUser || !supabase) { setProfile(null); setChats([]); return; }
    void loadAccount();
  }, [sessionUser]);

  async function loadAccount() {
    if (!supabase || !sessionUser) return;
    const { data: userData } = await supabase.auth.getUser();
    const userPhone = userData.user?.phone ?? '';
    const { data, error: profileError } = await supabase.from('profiles').select('id,username,display_name,avatar_url,phone').eq('id', sessionUser).maybeSingle();
    if (profileError) setError(`تعذر تحميل الملف الشخصي: ${profileError.message}`);
    if (!data) {
      const { data: created, error: createError } = await supabase.from('profiles').upsert({ id: sessionUser, phone: userPhone, display_name: 'مستخدم NOVA' }).select().single();
      if (createError) setError(`تعذر إنشاء الملف الشخصي: ${createError.message}`); else setProfile(created as Profile);
    } else setProfile(data as Profile);
    await loadChats();
  }

  async function loadChats() {
    if (!supabase || !sessionUser) return;
    const { data, error: listError } = await supabase.from('conversation_members').select('conversation_id, conversations(id,type,title,created_at)').eq('user_id', sessionUser);
    if (listError) { setError(`تعذر تحميل المحادثات: ${listError.message}`); return; }
    const rows: Chat[] = (data ?? []).map((row: any) => ({ id: row.conversations.id, type: row.conversations.type, title: row.conversations.title || (row.conversations.type === 'group' ? 'مجموعة جديدة' : 'محادثة') }));
    setChats(rows); if (!active && rows.length) setActive(rows[0]);
  }

  useEffect(() => {
    if (!active || !sessionUser) { setMessages([]); return; }
    let alive = true;
    void localDb.messages.where('conversation_id').equals(active.id).sortBy('created_at').then(rows => { if (alive) setMessages(rows); });
    if (supabase && online) {
      supabase.from('messages').select('id,conversation_id,sender_id,content,created_at').eq('conversation_id', active.id).order('created_at').limit(100).then(({ data }) => {
        if (!alive || !data) return;
        const mapped: LocalMessage[] = data.map((m: any) => ({ ...m, status: 'sent' }));
        void localDb.messages.bulkPut(mapped); setMessages(mapped);
      });
      const channel = supabase.channel(`messages:${active.id}`).on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${active.id}` }, payload => {
        const m = payload.new as any; const row: LocalMessage = { id: m.id, conversation_id: m.conversation_id, sender_id: m.sender_id, content: m.content, created_at: m.created_at, status: 'sent' };
        void localDb.messages.put(row); setMessages(prev => prev.some(x => x.id === row.id) ? prev : [...prev, row]);
      }).subscribe();
      return () => { alive = false; void supabase?.removeChannel(channel); };
    }
    return () => { alive = false; };
  }, [active?.id, sessionUser, online]);

  useEffect(() => { if (online && sessionUser) void syncPendingMessages(); }, [online, sessionUser]);

  const filteredChats = useMemo(() => chats.filter(c => c.title.toLowerCase().includes(search.toLowerCase())), [chats, search]);

  async function sendOtp() {
    if (!supabase) { setError('إعدادات Supabase غير موجودة. راجع ملف README وأضف مفاتيح المشروع.'); return; }
    const value = phone.replace(/[\s()-]/g, '');
    if (!/^\+[1-9]\d{7,14}$/.test(value)) { setError('اكتب رقم الهاتف بالصيغة الدولية، مثال: +201xxxxxxxxx'); return; }
    setBusy(true); setError('');
    const { error: otpError } = await supabase.auth.signInWithOtp({ phone: value, options: { shouldCreateUser: true } });
    if (otpError) setError(otpError.message); else setOtpSent(true);
    setBusy(false);
  }

  async function verifyOtp() {
    if (!supabase) return;
    if (!/^\d{6}$/.test(otp)) { setError('كود التحقق يجب أن يتكون من 6 أرقام.'); return; }
    setBusy(true); setError('');
    const { error: verifyError } = await supabase.auth.verifyOtp({ phone: phone.replace(/[\s()-]/g, ''), token: otp, type: 'sms' });
    if (verifyError) setError(verifyError.message);
    setBusy(false);
  }

  async function sendMessage() {
    const content = draft.trim(); if (!content || !sessionUser || !active) return;
    const row: LocalMessage = { id: crypto.randomUUID(), conversation_id: active.id, sender_id: sessionUser, content, created_at: new Date().toISOString(), status: 'pending' };
    await savePendingMessage(row); setMessages(prev => [...prev, row]); setDraft('');
    if (online) await syncPendingMessages();
  }

  async function createConversation() {
    if (!supabase) return;
    const target = newPhone.trim().replace(/[\s()-]/g, '');
    if (!/^\+[1-9]\d{7,14}$/.test(target)) { setError('اكتب رقم الهاتف بالصيغة الدولية.'); return; }
    const { data: targetProfile, error: lookupError } = await supabase.from('profiles').select('id,display_name').eq('phone', target).maybeSingle();
    if (lookupError || !targetProfile) { setError('لم نجد مستخدمًا مسجلًا بهذا الرقم.'); return; }
    const { data: conversationId, error: rpcError } = await supabase.rpc('create_direct_conversation', { other_user_id: targetProfile.id });
    if (rpcError) { setError(`تعذر إنشاء المحادثة: ${rpcError.message}`); return; }
    const { data: conv } = await supabase.from('conversations').select('id,type,title').eq('id', conversationId).single();
    if (conv) { const created: Chat = { id: conv.id, type: conv.type, title: conv.title || targetProfile.display_name || 'محادثة' }; setChats(prev => prev.some(c => c.id === created.id) ? prev : [created, ...prev]); setActive(created); }
    await loadChats(); setNewPhone(''); setSection('الدردشات');
  }

  async function signOut() { await supabase?.auth.signOut(); setSessionUser(null); setProfile(null); setMessages([]); }

  if (authLoading) return <main className={`app ${dark ? 'dark' : 'light'} auth-screen`}><div className="loader-mark">N</div><h2>NOVA CHAT</h2><p>جارٍ تجهيز مساحتك...</p></main>;

  if (!sessionUser) return <main className={`app ${dark ? 'dark' : 'light'} auth-screen`} dir="rtl">
    <div className="ambient ambient-one"/><div className="ambient ambient-two"/>
    <header className="topbar"><Brand/><button className="icon-btn" onClick={() => setDark(!dark)}>{dark ? <Sun/> : <Moon/>}</button></header>
    <section className="auth-gate panel">
      <div className="auth-symbol"><MessageCircle size={30}/></div><h1>{otpSent ? 'تأكيد رقم الهاتف' : 'تواصل بلا حدود'}</h1>
      <p>{otpSent ? `أدخل رمز التحقق المرسل إلى ${phone}` : 'مرحبًا بك في NOVA CHAT. سجّل برقم هاتفك للبدء.'}</p>
      {!isSupabaseConfigured && <div className="config-warning">التطبيق يحتاج إعداد Supabase وتفعيل Phone Authentication قبل إرسال رموز SMS.</div>}
      {!otpSent ? <><label>رقم الموبايل</label><input className="form-input" type="tel" inputMode="tel" autoComplete="tel" dir="ltr" value={phone} onChange={e => setPhone(e.target.value)} placeholder="+201xxxxxxxxx"/><button className="primary-wide" disabled={!supabase || busy} onClick={() => void sendOtp()}>{busy ? 'جارٍ الإرسال...' : 'إرسال كود التحقق'}</button></> : <><label>كود OTP</label><input className="form-input otp-input" dir="ltr" inputMode="numeric" autoComplete="one-time-code" maxLength={6} value={otp} onChange={e => setOtp(e.target.value.replace(/\D/g,'').slice(0,6))} placeholder="000000"/><button className="primary-wide" disabled={!supabase || busy || otp.length !== 6} onClick={() => void verifyOtp()}>{busy ? 'جارٍ التحقق...' : 'تأكيد ودخول'}</button><button className="text-action" onClick={() => { setOtpSent(false); setOtp(''); setError(''); }}>تغيير الرقم</button><button className="text-action" onClick={() => void sendOtp()}>إعادة إرسال الرمز</button></>}
      {error && <div className="auth-error">{error}</div>}<small className="auth-footnote">التسجيل متاح برقم الهاتف فقط. لا يوجد تسجيل بالبريد الإلكتروني أو حسابات خارجية.</small>
    </section>
  </main>;

  return <main className={`app ${dark ? 'dark' : 'light'}`} dir="rtl">
    <div className="ambient ambient-one"/><div className="ambient ambient-two"/>
    <header className="topbar"><Brand/><div className="top-actions"><div className={`connection ${online ? 'online' : 'offline'}`}>{online ? <Wifi size={15}/> : <WifiOff size={15}/>}<span>{online ? 'متصل' : 'بدون إنترنت'}</span></div><button className="icon-btn" onClick={() => setDark(!dark)} aria-label="تغيير المظهر">{dark ? <Sun/> : <Moon/>}</button><button className="icon-btn" onClick={() => setShowSettings(!showSettings)} aria-label="الإعدادات"><Settings/></button></div></header>
    {showSettings ? <section className="settings-page panel"><div className="settings-head"><button className="icon-btn" onClick={() => setShowSettings(false)}><ArrowLeft/></button><h2>الإعدادات</h2></div><div className="settings-profile"><div className="avatar self"><UserRound/></div><div><b>{profile?.display_name ?? 'مستخدم NOVA'}</b><small dir="ltr">{profile?.phone ?? ''}</small></div></div><button className="setting-row"><UserRound/> الملف الشخصي <span>›</span></button><button className="setting-row"><Bell/> الإشعارات <span>›</span></button><button className="setting-row"><Shield/> الخصوصية والأمان <span>›</span></button><button className="setting-row"><Archive/> التخزين والبيانات <span>›</span></button><button className="setting-row" onClick={() => setDark(!dark)}>{dark ? <Sun/> : <Moon/>} المظهر <span>{dark ? 'داكن' : 'فاتح'}</span></button><button className="setting-row danger" onClick={() => void signOut()}><LogOut/> تسجيل الخروج</button><p className="security-disclaimer">حالة الأمان: يلزم استكمال إعدادات الخادم والإشعارات والتشفير قبل النشر العام. لا تدّعي هذه النسخة وجود تشفير طرفي.</p></section> : <section className="workspace">
      <aside className="sidebar panel"><div className="profile-row"><div className="avatar self"><UserRound/></div><div className="profile-copy"><b>{profile?.display_name ?? 'مستخدم NOVA'}</b><small>حساب موثّق برقم الهاتف</small></div><button className="icon-btn" onClick={() => setShowSettings(true)}><Settings size={18}/></button></div>
        <label className="searchbox"><Search size={17}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="ابحث في المحادثات..."/></label>
        <div className="tabs"><button className={section === 'الدردشات' ? 'selected' : ''} onClick={() => setSection('الدردشات')}>الكل</button><button className={section === 'غير مقروءة' ? 'selected' : ''} onClick={() => setSection('غير مقروءة')}>غير مقروءة</button><button className={section === 'المفضلة' ? 'selected' : ''} onClick={() => setSection('المفضلة')}>المفضلة</button></div>
        <div className="section-label">المحادثات <span>{filteredChats.length}</span></div><div className="chat-list">{filteredChats.map(chat => <button key={chat.id} className={`chat-item ${active?.id === chat.id ? 'active' : ''}`} onClick={() => setActive(chat)}><div className={`avatar ${chat.type === 'group' ? 'blue' : 'violet'}`}>{chat.title.slice(0,1)}</div><div className="chat-info"><div className="chat-title"><b>{chat.title}</b><time>{fmt(chat.updated_at)}</time></div><div className="chat-preview"><span>{chat.lastMessage ?? (chat.type === 'group' ? 'مجموعة' : 'ابدأ المحادثة')}</span></div></div></button>)}{!filteredChats.length && <div className="empty-state"><MessageCircle size={28}/><b>لا توجد محادثات بعد</b><span>ابدأ محادثة جديدة باستخدام زر +</span></div>}</div>
        <button className="new-chat-button" onClick={() => setSection(section === 'محادثة جديدة' ? 'الدردشات' : 'محادثة جديدة')}><Plus size={18}/> محادثة جديدة</button><div className="sidebar-bottom"><span>✦ NOVA CHAT</span><span>نسخة تأسيسية</span></div>
      </aside>
      <section className="conversation panel">{section === 'محادثة جديدة' ? <div className="new-conversation"><div className="auth-symbol"><Users/></div><h2>محادثة جديدة</h2><p>أدخل رقم هاتف الشخص المسجل في NOVA CHAT</p><input className="form-input" dir="ltr" value={newPhone} onChange={e => setNewPhone(e.target.value)} placeholder="+201xxxxxxxxx"/><button className="primary-wide" onClick={() => void createConversation()}>بدء المحادثة</button>{error && <div className="auth-error">{error}</div>}</div> : active ? <><div className="conversation-head"><div className="avatar violet">{active.title.slice(0,1)}</div><div className="head-copy"><b>{active.title}</b><small>{active.type === 'group' ? 'مجموعة' : 'محادثة خاصة'}</small></div><div className="head-actions"><button className="icon-btn" title="مكالمة صوتية"><Phone/></button><button className="icon-btn" title="المزيد"><MoreVertical/></button></div></div><div className="messages-area"><div className="date-divider"><span>بداية المحادثة</span></div>{messages.map(m => <motion.div initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} key={m.id} className={`message-row ${m.sender_id === sessionUser ? 'mine' : 'theirs'}`}><div className="bubble"><p>{m.content}</p><div className="message-meta"><time>{fmt(m.created_at)}</time>{m.sender_id === sessionUser && (m.status === 'sent' ? <CheckCheck size={14}/> : <span>{m.status === 'pending' ? 'بانتظار الإرسال' : 'تعذر الإرسال'}</span>)}</div></div></motion.div>)}{!messages.length && <div className="welcome-card"><div className="welcome-icon"><MessageCircle/></div><b>ابدأ المحادثة</b><p>الرسائل هنا تُحفظ محليًا وتتم مزامنتها عند توفر الإنترنت.</p></div>}</div><div className="composer-wrap">{!online && <div className="offline-note"><WifiOff size={14}/> غير متصل — سيتم حفظ الرسالة وإرسالها عند عودة الإنترنت</div>}<div className="composer"><button className="icon-btn" title="إرفاق ملف" disabled><Paperclip/></button><input value={draft} onChange={e => setDraft(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') void sendMessage(); }} placeholder="اكتب رسالتك هنا..."/><button className="send-btn" onClick={() => void sendMessage()} disabled={!draft.trim()} aria-label="إرسال"><Send size={18}/></button></div><div className="composer-foot"><span>الرسائل النصية</span><span>Enter للإرسال</span></div></div></> : <div className="empty-conversation"><div className="brand-mark large">N</div><h2>أهلًا بك في NOVA CHAT</h2><p>ابدأ محادثة جديدة للتواصل مع أصدقائك.</p></div>}</section>
      <aside className="right-rail"><div className="rail-card panel"><div className="rail-icon blue-icon"><Users/></div><b>المجموعات</b><p>إنشاء المجموعات وإدارة الأعضاء يحتاج إلى استكمال صلاحيات الإدارة.</p><button disabled>قريبًا</button></div><div className="rail-card panel"><div className="rail-icon pink-icon"><Radio/></div><b>القنوات والحالات</b><p>هيكل قاعدة البيانات قابل للإضافة، والواجهات التنفيذية ضمن المراحل التالية.</p><button disabled>قريبًا</button></div><div className="rail-card panel"><div className="rail-icon"><RefreshCw/></div><b>المزامنة</b><p>{online ? 'الاتصال متاح. تتم محاولة مزامنة الرسائل المعلقة.' : 'أنت غير متصل. الرسائل الجديدة تحفظ محليًا.'}</p><button disabled>{online ? 'متصل' : 'Offline'}</button></div><div className="secure-note"><div>✦</div><span>الخصوصية أولًا</span><small>لا تستخدم هذه النسخة لمعلومات حساسة قبل استكمال مراجعة الأمان والتشفير.</small></div></aside>
    </section>}
    <footer className="mobile-footer"><button onClick={() => { setShowSettings(false); setSection('الدردشات'); }}><MessageCircle/>الدردشات</button><button onClick={() => setSection('المجموعات')}><Users/>المجموعات</button><button onClick={() => setSection('المكالمات')}><Phone/>المكالمات</button><button onClick={() => setShowSettings(true)}><Settings/>الإعدادات</button></footer>
  </main>;
}

function Brand() { return <div className="brand"><div className="brand-mark">N</div><div><b>NOVA</b><span>CHAT</span></div></div>; }

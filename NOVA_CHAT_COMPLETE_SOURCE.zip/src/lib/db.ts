import Dexie, { type Table } from 'dexie';
export interface LocalMessage { id: string; conversation_id: string; sender_id: string; content: string; created_at: string; status: 'pending' | 'sent' | 'failed'; }
class NovaDatabase extends Dexie {
  messages!: Table<LocalMessage, string>;
  constructor() { super('nova-chat-local'); this.version(1).stores({ messages: 'id, conversation_id, sender_id, created_at, status' }); }
}
export const localDb = new NovaDatabase();

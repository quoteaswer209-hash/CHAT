# NOVA CHAT — Android / Web starter

A React + TypeScript + Vite + Capacitor application with **phone-number OTP only**. NOVA AI and all AI-related UI/features have been removed.

## What's included now

- Arabic-first responsive interface, RTL, dark/light appearance.
- Phone OTP authentication using Supabase Auth (`signInWithOtp` + `verifyOtp`). No email/password/social login paths.
- Profile bootstrap from the verified Supabase phone number.
- Supabase-backed conversation list and direct-chat creation by the other user's verified phone number.
- Realtime text-message subscription for an opened conversation.
- Local IndexedDB message cache and a pending-message queue that attempts synchronization when the connection returns.
- Database schema for profiles, conversations, memberships, messages, receipts, attachments, reactions, groups, channels, stories, calls and notifications.
- Capacitor Android configuration and GitHub Actions workflow to build a debug APK.

## Important implementation status

This ZIP is a **working foundation**, not a claim that every feature in the original product brief is already complete. The following require additional service setup and implementation before public release:

- SMS OTP: configure a supported SMS provider in Supabase Auth > Phone. Supabase may require provider credentials and phone auth settings.
- Attachments: create a private Supabase Storage bucket named `nova-media`, then add member-aware Storage policies. File upload/download UI is not implemented yet.
- Voice/video calls: require a WebRTC signaling service and STUN/TURN infrastructure. The call buttons are visual entry points only at this stage.
- Push notifications: require Firebase Cloud Messaging and a native Capacitor push-notifications integration.
- End-to-end encryption: not implemented. Do not describe this build as E2EE or use it for sensitive messages.
- Nearby Bluetooth/Wi-Fi Direct: requires native Android implementation and permissions; not implemented in this web layer.
- Group administration, channels publishing, Stories, message receipts, reactions, message editing/forwarding, QR, contact sync and advanced privacy controls: database foundation exists for several of these, but the complete screens and workflows still need implementation.
- Offline mode currently caches text messages for conversations already available to the signed-in account. First-time sign-in and server actions still require internet. It is not a full offline-first replica of all WhatsApp/Telegram features.

No sample conversations or fake contacts are inserted. A newly registered user sees an empty chat list until they start a chat with another registered phone number.

## 1. Create a Supabase project

1. Create a project at Supabase.
2. In Project Settings > API, copy the Project URL and `anon` public key.
3. In Authentication > Providers, enable **Phone**.
4. Configure an SMS provider supported by Supabase and its credentials. For production, configure SMS rate limits and abuse protection.
5. Open SQL Editor and run the complete file `supabase/schema.sql`.
6. In Database > Publications, enable `messages` for `supabase_realtime`.
7. Create a **private** Storage bucket named `nova-media` only when you are ready to add file upload policies.

## 2. Configure environment variables

Copy `.env.example` to `.env` and fill in:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_PUBLIC_KEY
```

Only the Supabase anon/public key belongs in the client. **Never put a service-role key or SMS provider secret in this app or GitHub repository.**

For GitHub Actions builds, add repository Actions Variables named `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`, then expose them to the build step. The included workflow reads these repository variables.

## 3. Run locally

```bash
npm install
npm run dev
```

Production web build:

```bash
npm run build
```

## 4. Build Android APK

```bash
npm install
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

APK output:

`android/app/build/outputs/apk/debug/app-debug.apk`

The GitHub Actions workflow at `.github/workflows/build.yml` performs the same build and uploads the debug APK as an artifact. Upload the **contents of this ZIP** to the new repository (including the hidden `.github` folder), commit to `main`, then open Actions.

## 5. OTP phone format

Enter phone numbers in E.164 format, e.g. `+201xxxxxxxxx`. The user must receive and verify the SMS before the authenticated part of the app becomes available.

## Security notes

- Supabase Row Level Security is enabled in the SQL schema. Review all policies against your production threat model before launch.
- Phone numbers are personal data. Limit access and publish a privacy policy before public release.
- Do not claim delivery/read receipts until the relevant server-side confirmation flow is implemented.
- Do not claim end-to-end encryption until a vetted protocol and audited key-management implementation are integrated.
